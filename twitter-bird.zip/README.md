# twitter-bird
A browser extension to replace the main Twitter icon and favicon icon with the canonical Bird.

<a href='https://chrome.google.com/webstore/detail/twitter-bird/ihahjhhimifemcpmbghgjmniofjchmlh/'><img alt='Get it for Chrome' src='https://user-images.githubusercontent.com/18288554/255850256-46bf43fd-468f-47dd-b69e-4c32266250cd.png' width='200'/></a>
<a href='https://addons.mozilla.org/en-US/firefox/addon/twitter-bird-changer/'><img alt='Get it for Firefox' src='https://user-images.githubusercontent.com/18288554/255849659-9f7b0092-3acf-41ef-a363-4f378c95a17c.png' width='200'/></a> 

![screenshot](https://github.com/Semper-Viventem/twitter-bird/assets/18288554/4e8eaa48-f463-4436-8eef-e77e8984fe2d)
