# twitter-bird
Google Chrome extension which returns the Twitter bird icon back

![screenshot](https://github.com/Semper-Viventem/twitter-bird/assets/18288554/4e8eaa48-f463-4436-8eef-e77e8984fe2d)
