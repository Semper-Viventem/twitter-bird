# twitter-bird
Google Chrome extension which returns the Twitter bird icon back
